package com.example.kyn.DTO;

import com.example.kyn.model.Caregiver;
import com.example.kyn.model.Donation;
import lombok.Data;

@Data
public class RegisDTO {
    private UserDTO userDTO;
    private Caregiver caregiver;



}
