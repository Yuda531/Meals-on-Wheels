package com.example.kyn.model;

public class Admin {
}
